import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import {
  BaseClientSideWebPart
} from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';

import * as strings from 'InventoryManagementWebPartStrings';

import InventoryManagement from './components/InventoryManagement';
import { IInventoryManagementProps } from './components/IInventoryManagementProps';

import { getSP } from './utils/PnPConfig';

export interface IInventoryManagementWebPartProps {
  description: string;
}

export default class InventoryManagementWebPart extends BaseClientSideWebPart<IInventoryManagementWebPartProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';

  protected async onInit(): Promise<void> {

    await super.onInit();

    // Initialize PnPJS
    getSP(this.context);

    // Load environment message
    this._environmentMessage = await this._getEnvironmentMessage();
  }

  public render(): void {

    const element: React.ReactElement<IInventoryManagementProps> =
      React.createElement(InventoryManagement, {
        description: this.properties.description,
        isDarkTheme: this._isDarkTheme,
        environmentMessage: this._environmentMessage,
        hasTeamsContext: !!this.context.sdks.microsoftTeams,
        userDisplayName: this.context.pageContext.user.displayName,

        // Pass SPFx Context
        context: this.context
      });

    ReactDom.render(element, this.domElement);
  }

  private async _getEnvironmentMessage(): Promise<string> {

    if (!!this.context.sdks.microsoftTeams) {

      const context = await this.context.sdks.microsoftTeams.teamsJs.app.getContext();

      switch (context.app.host.name) {

        case 'Office':
          return this.context.isServedFromLocalhost
            ? strings.AppLocalEnvironmentOffice
            : strings.AppOfficeEnvironment;

        case 'Outlook':
          return this.context.isServedFromLocalhost
            ? strings.AppLocalEnvironmentOutlook
            : strings.AppOutlookEnvironment;

        case 'Teams':
        case 'TeamsModern':
          return this.context.isServedFromLocalhost
            ? strings.AppLocalEnvironmentTeams
            : strings.AppTeamsTabEnvironment;

        default:
          return strings.UnknownEnvironment;
      }
    }

    return this.context.isServedFromLocalhost
      ? strings.AppLocalEnvironmentSharePoint
      : strings.AppSharePointEnvironment;
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {

    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;

    const { semanticColors } = currentTheme;

    if (semanticColors) {

      this.domElement.style.setProperty(
        '--bodyText',
        semanticColors.bodyText || null
      );

      this.domElement.style.setProperty(
        '--link',
        semanticColors.link || null
      );

      this.domElement.style.setProperty(
        '--linkHovered',
        semanticColors.linkHovered || null
      );
    }
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {

    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}